import React, { useState } from "react";
import { 
  View, Text, TextInput, TouchableOpacity, 
  FlatList, StyleSheet, KeyboardAvoidingView, Platform 
} from "react-native";
import LottieView from "lottie-react-native";
import Feather from "react-native-vector-icons/Feather";
import Sentiment from "sentiment";

// Import emotion keywords from local JSON
import emotionKeywords from "../../assets/emotionKeywords.json";

const sentimentAnalyzer = new Sentiment();
const HUGGING_FACE_API_KEY = "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"; // Replace with your real token

const KanmaniScreen = () => {
  const [messages, setMessages] = useState([
    { id: "1", text: "Hello! How can I assist you today?", sender: "kanmani" },
  ]);
  const [input, setInput] = useState("");

  // Local emotion keywords
  const analyzeEmotion = (text) => {
    const normalized = text.toLowerCase();
    for (let item of emotionKeywords) {
      for (let kw of item.keywords) {
        if (normalized.includes(kw)) {
          return item.response;
        }
      }
    }
    return null;
  };

  // Hugging Face API emotion detection
  const fetchEmotionFromHuggingFace = async (userText) => {
    try {
      const response = await fetch("https://api-inference.huggingface.co/models/bhadresh-savani/distilbert-base-uncased-emotion", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${HUGGING_FACE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs: userText }),
      });

      const result = await response.json();

      if (result && result[0]) {
        const topEmotion = result[0][0].label;
        switch (topEmotion) {
          case "joy": return "You seem happy! 😊 Tell me more!";
          case "anger": return "You're angry... want to vent it out?";
          case "sadness": return "I'm here for you. It's okay to feel sad. 💜";
          case "fear": return "That sounds scary. You're safe with me.";
          case "love": return "Aww, you're in a lovely mood! 💕";
          case "surprise": return "That was unexpected, right?";
          default: return "Hmm... I'm here to talk about anything you want.";
        }
      }
      return "Sorry, I couldn't quite understand that 😅";
    } catch (error) {
      console.error("Hugging Face Error:", error);
      return "Oops! Something went wrong while checking your mood. 😕";
    }
  };

  // Bot response generation
  const getBotResponse = async (userText) => {
    if (userText.trim().toLowerCase() === "yes") {
      return "Go ahead, I'm all ears!";
    }

    const emotionResponse = analyzeEmotion(userText);
    if (emotionResponse) return emotionResponse;

    const sentimentResult = sentimentAnalyzer.analyze(userText);
    if (sentimentResult.score > 2) return "You sound really positive! 😊";
    if (sentimentResult.score < -2) return "I'm sorry you're feeling down. Want to talk about it? 💜";

    return await fetchEmotionFromHuggingFace(userText);
  };

  const sendMessage = async (text) => {
    if (!text.trim()) return;

    const newUserMessage = { id: Date.now().toString(), text, sender: "user" };
    setMessages((prev) => [...prev, newUserMessage]);
    setInput("");

    setTimeout(async () => {
      const botReply = await getBotResponse(text);
      const newBotMessage = { id: Date.now().toString(), text: botReply, sender: "kanmani" };
      setMessages((prev) => [...prev, newBotMessage]);
    }, 800);
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      {/* Kanmani Animation */}
      <View style={styles.kanmaniContainer}>
        <LottieView
          source={require("../../assets/chatbotData.json")}
          autoPlay
          loop
          style={styles.kanmaniAnimation}
        />
      </View>

      {/* Chat Messages */}
      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[
            styles.chatBubble,
            item.sender === "user" ? styles.userBubble : styles.kanmaniBubble
          ]}>
            <Text style={[
              styles.chatText,
              item.sender === "user" ? { color: "#fff" } : { color: "#333" }
            ]}>
              {item.text}
            </Text>
          </View>
        )}
        contentContainerStyle={{ flexGrow: 1, justifyContent: "flex-start" }} 
      />

      {/* Input Field */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Type a message..."
          placeholderTextColor="#ddd"
          value={input}
          onChangeText={setInput}
        />
        <TouchableOpacity onPress={() => sendMessage(input)}>
          <Feather name="send" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default KanmaniScreen;

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FCE4EC",
    padding: 10,
  },
  kanmaniContainer: {
    alignItems: "center",
    marginBottom: 10,
  },
  kanmaniAnimation: {
    width: 100,
    height: 100,
  },
  chatBubble: {
    maxWidth: "75%",
    padding: 10,
    borderRadius: 20,
    marginBottom: 10,
  },
  userBubble: {
    backgroundColor: "#D988B9",
    alignSelf: "flex-end",
  },
  kanmaniBubble: {
    backgroundColor: "#fff",
    alignSelf: "flex-start",
  },
  chatText: {
    fontSize: 16,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#D988B9",
    borderRadius: 30,
    paddingHorizontal: 15,
    paddingVertical: 8,
    marginBottom: 10,
  },
  input: {
    flex: 1,
    color: "#fff",
    fontSize: 16,
  },
});
