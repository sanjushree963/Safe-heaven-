import React from "react";
import { 
  View, Text, Image, TouchableOpacity, 
  StyleSheet, StatusBar 
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import Feather from "react-native-vector-icons/Feather";

const PilotScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8E8EE" />

      {/* Top Navigation Bar */}
      <View style={styles.topNav}>
        <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
          <Feather name="user" size={24} color="#A6488E" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate("DM")}>
          <Feather name="message-circle" size={24} color="#A6488E" />
        </TouchableOpacity>
      </View>

      {/* Safety Guidance Module */}
      <TouchableOpacity style={styles.card}
      onPress={() => navigation.navigate("SafetyInsightsScreen")} // Navigate to SafetyInsightsScreen
      >
        <Image 
          source={require("../../assets/images/guidelines.png")} // Replace with your image
          style={styles.cardImage} 
        />
        <Text style={styles.cardText}>Safety Insights</Text>
      </TouchableOpacity>

          {/* Chatbot Module */}
          <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate("KanmaniScreen")} // Navigate to KanmaniScreen
          >
              <Image
                  source={require("../../assets/images/hug.png")} // Replace with your image
                  style={styles.cardImage}
              />
              <Text style={styles.cardText}>Kanmani</Text>
          </TouchableOpacity>


      {/* Security Module */}
      <TouchableOpacity 
      style={styles.card}
      onPress={() => navigation.navigate("SecureAssistScreen")} // Navigate to SecureAssistScreen
      >
        <Image 
          source={require("../../assets/images/lock.png")} // Replace with your image
          style={styles.cardImage} 
        />
        <Text style={styles.cardText}>Secure Assist</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8E8EE",
    alignItems: "center",
    paddingTop: 20,
  },
  topNav: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "90%",
    marginBottom: 20,
  },
  card: {
    width: "85%",
    backgroundColor: "#FFF",
    borderRadius: 20,
    alignItems: "center",
    padding: 20,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5, // Light shadow effect
    marginTop:20,


  },
  cardImage: {
    width: 100,
    height: 100,
    resizeMode: "contain",
    marginBottom: 10,
  },
  cardText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#A6488E",
  },
});

export default PilotScreen;
