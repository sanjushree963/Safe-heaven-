import { useState } from "react";
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, StatusBar, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import DateTimePicker from "@react-native-community/datetimepicker";
import { Picker } from "@react-native-picker/picker";
import { NavigationProp } from "@react-navigation/native";

type Props = {
  navigation: NavigationProp<any>; // Define the navigation type
};
export default function RegisterScreen({navigation}:Props) {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [birthdate, setBirthdate] = useState("");
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [gender, setGender] = useState("");
  const [showGenderPicker, setShowGenderPicker] = useState(false);

  const onChangeDate = (event: any, selectedDate: Date | undefined) => {
    setShowDatePicker(Platform.OS === "ios");
    if (selectedDate) {
      setBirthdate(selectedDate.toISOString().split("T")[0]);
    }
  };

  return (
    <>
      <StatusBar backgroundColor="#2E3A47" barStyle="light-content" />
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.container}>
          {/* Greeting */}
          <Text style={styles.greeting}>
            Hi, <Text style={styles.yellowText}>Register</Text> Now
          </Text>

          {/* Input Fields */}
          <View style={styles.inputContainer}>
            <TextInput style={styles.input} placeholder="Enter Username" placeholderTextColor="black" />
            <View style={styles.spacer} />
            <TextInput style={styles.input} placeholder="Enter Phone Number" placeholderTextColor="black" keyboardType="phone-pad" />
            <View style={styles.spacer} />
            
            {/* Birthdate Picker */}
            <TouchableOpacity onPress={() => setShowDatePicker(true)}>
              <TextInput
                style={styles.input}
                placeholder="Enter Birthdate"
                placeholderTextColor="black"
                value={birthdate}
                editable={false}
              />
            </TouchableOpacity>
            {showDatePicker && (
              <DateTimePicker
                value={new Date()}
                mode="date"
                display="default"
                onChange={onChangeDate}
              />
            )}
            <View style={styles.spacer} />
            
            {/* Gender Picker */}
            <TouchableOpacity onPress={() => setShowGenderPicker(!showGenderPicker)}>
              <TextInput
                style={styles.input}
                placeholder="Select Gender"
                placeholderTextColor="black"
                value={gender}
                editable={false}
              />
            </TouchableOpacity>
            {showGenderPicker && (
              <Picker
                selectedValue={gender}
                onValueChange={(itemValue) => {
                  setGender(itemValue);
                  setShowGenderPicker(false);
                }}
                style={styles.picker}
              >
                <Picker.Item label="Male" value="Male" />
                <Picker.Item label="Female" value="Female" />
                <Picker.Item label="Other" value="Other" />
              </Picker>
            )}
            <View style={styles.spacer} />
            
            {/* Password */}
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.passwordInput}
                placeholder="Enter Password"
                placeholderTextColor="black"
                secureTextEntry={!passwordVisible}
              />
              <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)}>
                <Ionicons name={passwordVisible ? "eye-off" : "eye"} size={24} color="black" />
              </TouchableOpacity>
            </View>
            <View style={styles.spacer} />

            {/* Confirm Password */}
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.passwordInput}
                placeholder="Confirm Password"
                placeholderTextColor="black"
                secureTextEntry={!confirmPasswordVisible}
              />
              <TouchableOpacity onPress={() => setConfirmPasswordVisible(!confirmPasswordVisible)}>
                <Ionicons name={confirmPasswordVisible ? "eye-off" : "eye"} size={24} color="black" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Register Button */}
          <TouchableOpacity style={[styles.button, styles.yellowButton]}
          onPress={() => navigation.navigate("LoginScreen")}
          >
            <Text style={styles.buttonText}>Register</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    flex: 1,
    backgroundColor: "#2E3A47",
    alignItems: "center",
    justifyContent: "flex-start",
    width: "100%",
    paddingBottom: 20,
  },
  greeting: {
    fontSize: 39,
    color: "white",
    marginTop: 50,
    paddingRight: 20,
    textAlign: "center",
  },
  yellowText: {
    color: "#DCD243",
  },
  inputContainer: {
    marginTop: 40,
    width: "90%",
  },
  input: {
    width: "100%",
    backgroundColor: "#FDFBA1",
    paddingVertical: 20,
    paddingHorizontal: 15,
    borderRadius: 10,
    fontSize: 16,
  },
  spacer: {
    height: 20,
  },
  picker: {
    width: "100%",
    backgroundColor: "#FDFBA1",
    borderRadius: 10,
    marginTop: 5,
  },
  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FDFBA1",
    borderRadius: 10,
    paddingHorizontal: 15,
  },
  passwordInput: {
    flex: 1, 
    fontSize: 16,
    paddingVertical: 20, 
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    width: "40%",
    marginTop: 30,
  },
  yellowButton: {
    backgroundColor: "#F0E65D",
  },
  buttonText: {
    color: "black",
    fontSize: 18,
  },
});
