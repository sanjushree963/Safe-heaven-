import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Image,
  StyleSheet,
  Linking,
  ActivityIndicator,
} from "react-native";
import { TabView, SceneMap, TabBar } from "react-native-tab-view";
import Ionicons from "react-native-vector-icons/Ionicons";

// Firebase imports
import { getFirestore, collection, getDocs } from "firebase/firestore";
import { app } from "../firebaseConfig"; // Adjust path as needed

/* ------------------------------------------
 * 1) INDIAN LAWS COMPONENT
 * Fetches data from Firestore and displays 
 * multiple laws, each in a collapsible card.
 * ------------------------------------------ */
const IndianLaws = () => {
  const [laws, setLaws] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Track collapsed state for each law using an object:
  // { 0: true/false, 1: true/false, ... }
  const [collapsedIndices, setCollapsedIndices] = useState({});

  useEffect(() => {
    const fetchLaws = async () => {
      try {
        const db = getFirestore(app);
        const querySnapshot = await getDocs(collection(db, "Indian Laws"));
        const lawsList = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        console.log("Fetched laws:", lawsList); // Debug output
        setLaws(lawsList);
      } catch (err) {
        console.error("Error fetching laws:", err);
        setError("Failed to load laws. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchLaws();
  }, []);

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#A6488E" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.loaderContainer}>
        <Text style={{ color: "red", textAlign: "center" }}>{error}</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scene}>
      <Text style={styles.sectionTitle}>Indian Laws for Women's Safety</Text>
      {laws.map((law, index) => {
        // If we never clicked this law, default collapsed = true
        const isCollapsed = collapsedIndices[index] ?? true;

        return (
          <View key={law.id} style={styles.lawContainer}>
            {/* Tapping the title toggles collapsed state */}
            <TouchableOpacity
              onPress={() =>
                setCollapsedIndices((prev) => ({
                  ...prev,
                  [index]: !prev[index],
                }))
              }
            >
              <Text style={styles.lawTitle}>{law.Title}</Text>
            </TouchableOpacity>

            {/* If not collapsed, show the law description */}
            {!isCollapsed && (
              <Text style={styles.lawDetails}>{law.Description}</Text>
            )}
          </View>
        );
      })}
    </ScrollView>
  );
};

/* ------------------------------------------
 * 2) SELF-DEFENSE VIDEOS COMPONENT
 * Fetches data from Firestore and displays
 * clickable video cards (thumbnail + title).
 * ------------------------------------------ */
const SelfDefenseVideos = () => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const db = getFirestore(app);
        const querySnapshot = await getDocs(collection(db, "Self Defense Videos"));
        const videosArr = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setVideos(videosArr);
      } catch (err) {
        setError("Failed to load videos. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchVideos();
  }, []);

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#A6488E" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.loaderContainer}>
        <Text style={{ color: "red", textAlign: "center" }}>{error}</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scene}>
      <Text style={styles.sectionTitle}>Self-Defense Video Tutorials</Text>
      <View style={styles.videoContainer}>
        {videos.map((video) => (
          <View key={video.id} style={styles.videoCard}>
            <TouchableOpacity onPress={() => Linking.openURL(video.Link)}>
              <Image
                source={{ uri: video.Thumbnail }}
                style={styles.videoThumbnail}
              />
              <Text style={styles.videoTitle}>{video.Title}</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

/* ------------------------------------------
 * 3) SELF-DEFENSE PRODUCTS COMPONENT
 * Fetches data from Firestore and displays
 * product items (image + name), clickable link.
 * ------------------------------------------ */
const SelfDefenseProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const db = getFirestore(app);
        const querySnapshot = await getDocs(
          collection(db, "Self Defense Products")
        );
        const productsArr = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setProducts(productsArr);
      } catch (err) {
        setError("Failed to load products. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#A6488E" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.loaderContainer}>
        <Text style={{ color: "red", textAlign: "center" }}>{error}</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scene}>
      <Text style={styles.sectionTitle}>Self-Defense Products</Text>
      {products.map((product) => (
        <TouchableOpacity
          key={product.id}
          onPress={() => Linking.openURL(product.Link)}
          style={styles.productContainer}
        >
          <Image
            source={{ uri: product.Image }}
            style={styles.productImage}
          />
          <Text style={styles.productName}>{product.Name}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

/* ------------------------------------------
 * 4) TAB VIEW SETUP
 * We define each route (laws, videos, products)
 * and link them to our 3 components above.
 * ------------------------------------------ */
import { useWindowDimensions } from "react-native";

const SafetyInsightsScreen = ({ navigation }) => {
  const layout = useWindowDimensions();
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    { key: "laws", title: "Indian Laws" },
    { key: "videos", title: "Videos" },
    { key: "products", title: "Products" },
  ]);

  const renderScene = ({ route }) => {
    switch (route.key) {
      case "laws":
        return <IndianLaws />;
      case "videos":
        return <SelfDefenseVideos />;
      case "products":
        return <SelfDefenseProducts />;
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#A6488E" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Safety Insights</Text>
        </View>
        <TouchableOpacity onPress={() => console.log("Search pressed")}>
          <Ionicons name="search" size={24} color="#A6488E" />
        </TouchableOpacity>
      </View>

      {/* Tab View */}
      <TabView
        navigationState={{ index, routes }}
        renderScene={renderScene}
        onIndexChange={setIndex}
        initialLayout={{ width: layout.width }}
        renderTabBar={(props) => (
          <TabBar
            {...props}
            style={styles.tabBar}
            indicatorStyle={styles.indicator}
            renderLabel={({ route, focused }) => (
              <Text
                style={[
                  styles.tabLabel,
                  { color: focused ? "#D988B9" : "#000" },
                ]}
              >
                {route.title}
              </Text>
            )}
          />
        )}
      />
    </SafeAreaView>
  );
};

export default SafetyInsightsScreen;

/* ------------------------------------------
 * 5) STYLES - PRESERVED FROM YOUR CODE
 * We keep your existing style structure
 * ------------------------------------------ */



const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F8E8EE",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 20,
    color: "#A6488E",
    fontWeight: "bold",
    marginLeft: 10,
  },
  tabBar: {
    backgroundColor: "#FF94D5",
    elevation: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
  },
  indicator: {
    backgroundColor: "white",
    height: 3,
  },
  tabLabel: {
    fontSize: 18,
    fontWeight: "bold",
  },
  scene: {
    padding: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#black", // or any color
    marginBottom: 15,
  },
  lawContainer: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
  },
  lawTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FF5892",
  },
  lawDetails: {
    marginTop: 10,
    fontSize: 14,
    color: "#333",
  },
  videoContainer: {
    marginBottom: 15,
  },
  videoCard: {
    backgroundColor: "#fff",
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
    overflow: "hidden",
  },
  videoThumbnail: {
    width: "100%",
    height: 150,
  },
  videoTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FF5892",
    padding: 10,
  },
  productContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
    marginRight: 15,
  },
  productName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FF5892",
  },

  // Additional style for loading container
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
});
