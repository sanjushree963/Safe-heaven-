import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
  Alert,
  ScrollView,
  Vibration,
} from "react-native";
import Feather from "react-native-vector-icons/Feather";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, db } from "../firebaseConfig";
import { Accelerometer } from "expo-sensors";
import * as FileSystem from "expo-file-system";
import { useNavigation } from '@react-navigation/native';

const SecureAssistScreen = () => {
  const navigation = useNavigation();
  const [peopleCount, setPeopleCount] = useState(null);
  const [armedSelection, setArmedSelection] = useState(null);
  const [weaponType, setWeaponType] = useState(null);
  const [dangerLevel, setDangerLevel] = useState(null);
  const [emergencyContacts, setEmergencyContacts] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [subscription, setSubscription] = useState(null);
  const [sensorAvailable, setSensorAvailable] = useState(false);

  const liveLocation = { latitude: 12.9716, longitude: 77.5946 };
  const ESP8266_IP = "192.168.114.51"; // Replace with your actual IP

  useEffect(() => {
    const fetchEmergencyContacts = async () => {
      const user = auth.currentUser;
      if (!user) return;
      try {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        if (userDoc.exists()) {
          setEmergencyContacts(userDoc.data().emergencyContacts || []);
        }
      } catch (error) {
        console.error("Error fetching emergency contacts:", error);
      }
    };
    fetchEmergencyContacts();

    const setupAccelerometer = async () => {
      try {
        const isAvailable = await Accelerometer.isAvailableAsync();
        setSensorAvailable(isAvailable);
        if (isAvailable) {
          const accelSubscription = Accelerometer.addListener(({ x, y, z }) => {
            const acceleration = Math.sqrt(x * x + y * y + z * z);
            if (acceleration > 20) {
              handleShake();
            }
          });
          Accelerometer.setUpdateInterval(100);
          setSubscription(accelSubscription);
        } else {
          console.warn("Accelerometer is not available on this device");
          Alert.alert(
            "Sensor Error",
            "Accelerometer is not available. Please use the SOS button manually."
          );
        }
      } catch (error) {
        console.error("Error setting up accelerometer:", error);
        Alert.alert("Sensor Error", "Failed to initialize sensors.");
      }
    };
    setupAccelerometer();

    return () => {
      if (subscription) {
        subscription.remove();
      }
    };
  }, []);

  const handleShake = async () => {
    if (!sensorAvailable) {
      Alert.alert("Error", "Sensors are not available. Trigger manually.");
      return;
    }

    Vibration.vibrate([500, 500, 500]);
    Alert.alert("🚨 SOS Triggered!", "Sending signal to hardware...");

    try {
      const response = await fetch(`http://${ESP8266_IP}/record`, {
        method: "GET",
        timeout: 5000,
      });
      const text = await response.text();
      if (text === "Recording started") {
        setIsRecording(true);
        Alert.alert("⚠️ Alert!", "Recording started on hardware!");
        await uploadVideoToFirebase();
      }
    } catch (error) {
      console.error("Failed to trigger recording:", error);
      Alert.alert("Error", "Could not connect to hardware");
    }

    handleSOSPress();
    setTimeout(() => setIsRecording(false), 5000);
  };

  const handleSOSPress = async () => {
    let message = `🚨 SOS Alert Sent!\nLive Location: (${liveLocation.latitude}, ${liveLocation.longitude})\n`;
    if (peopleCount || armedSelection !== null || dangerLevel) {
      message += `\n🆘 Situation Details:\n- People: ${peopleCount || "N/A"}\n- Armed: ${
        armedSelection || "N/A"
      }\n`;
      if (armedSelection === "Yes") {
        message += `- Weapon: ${weaponType || "Not Specified"}\n`;
      }
      message += `- Danger Level: ${dangerLevel || "N/A"}`;
    }
    Alert.alert("⚠️ SOS Alert!", message, [{ text: "OK" }]);
    try {
      const response = await fetch(`http://${ESP8266_IP}/record`, {
        method: "GET",
      });
    
      const text = await response.text();
      console.log("ESP response:", text);
    
      if (text.toLowerCase().includes("started")) {
        Alert.alert("✅ Recording", "Smart Box started recording.");
      } else {
        Alert.alert("ℹ️ ESP says:", text);
      }
    } catch (error) {
      Alert.alert("❌ Error", "Could not contact Smart Box. Is it powered on?");
    }
  };

  const uploadVideoToFirebase = async () => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      const videoUrl = `http://${ESP8266_IP}/video`;
      const videoResponse = await fetch(videoUrl);
      const videoBlob = await videoResponse.blob();

      const fileUri = `${FileSystem.cacheDirectory}recorded_video.mp4`;
      await FileSystem.writeAsStringAsync(fileUri, videoBlob, {
        encoding: FileSystem.EncodingType.Base64,
      });

      const storageRef = `videos/${user.uid}/${Date.now()}_video.mp4`;
      await setDoc(doc(db, "sosRecords", `${user.uid}_${Date.now()}`), {
        videoUrl: storageRef,
        location: liveLocation,
        timestamp: new Date().toISOString(),
        details: {
          peopleCount,
          armedSelection,
          weaponType,
          dangerLevel,
        },
      });
      console.log("Video metadata saved to Firestore");
    } catch (error) {
      console.error("Failed to upload video to Firebase:", error);
      Alert.alert("Error", "Failed to save video to Firebase");
    }
  };

  const callContact = (phone) => Linking.openURL(`tel:${phone}`);
  const sendSMS = (phone) => Linking.openURL(`sms:${phone}`);

  const renderRadioOption = (option, selected, onSelect) => (
    <TouchableOpacity
      key={option}
      style={[
        styles.optionButton,
        selected === option && styles.optionButtonSelected,
      ]}
      onPress={() => onSelect(option)}
    >
      <Text
        style={[
          styles.optionText,
          selected === option && styles.optionTextSelected,
        ]}
      >
        {option}
      </Text>
    </TouchableOpacity>
  );

  const handleBackPress = () => {
    navigation.goBack();
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBackPress}>
          <Feather name="arrow-left" size={24} color="#A6488E" />
        </TouchableOpacity>
        <Text style={styles.title}>Secure Assist</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Situation Details (Optional)</Text>
        <Text style={styles.question}>How many people?</Text>
        <View style={styles.optionsRow}>
          {["1", "2", "3", "4", "5", "5<"].map((option) =>
            renderRadioOption(option, peopleCount, setPeopleCount)
          )}
        </View>
        <Text style={styles.question}>Are they armed?</Text>
        <View style={styles.optionsRow}>
          {["Yes", "No"].map((option) =>
            renderRadioOption(option, armedSelection, (val) => {
              setArmedSelection(val);
              if (val === "No") setWeaponType(null);
            })
          )}
        </View>
        {armedSelection === "Yes" && (
          <>
            <Text style={styles.question}>What type of weapon?</Text>
            <View style={styles.optionsRow}>
              {["Gun", "Knife", "Acid", "Rifle", "Other"].map((option) =>
                renderRadioOption(option, weaponType, setWeaponType)
              )}
            </View>
          </>
        )}
        <Text style={styles.question}>How dangerous is the situation?</Text>
        <View style={styles.optionsRow}>
          {["Little Safe", "Super Danger"].map((option) =>
            renderRadioOption(option, dangerLevel, setDangerLevel)
          )}
        </View>
      </View>

      <TouchableOpacity style={styles.sosButton} onPress={handleSOSPress}>
        <Text style={styles.sosButtonText}>🚨</Text>
      </TouchableOpacity>

      <Text style={styles.sectionTitle}>Emergency Contacts</Text>
      {emergencyContacts.map((item, index) => (
        <View key={index} style={styles.contactCard}>
          <Text style={styles.contactName}>{item.name}</Text>
          <View style={styles.contactActions}>
            <TouchableOpacity
              style={styles.iconButton}
              onPress={() => callContact(item.phone)}
            >
              <Feather name="phone" size={20} color="green" />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.iconButton}
              onPress={() => sendSMS(item.phone)}
            >
              <Feather name="message-circle" size={20} color="#A6488E" />
            </TouchableOpacity>
          </View>
        </View>
      ))}

      <View style={styles.rowButtons}>
        <TouchableOpacity
          style={styles.policeButton}
          onPress={() => callContact("100")}
        >
          <Text style={styles.policeText}>🚔 Call Police</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.ambulanceButton}
          onPress={() => callContact("108")}
        >
          <Text style={styles.ambulanceText}>🚑 Call Ambulance</Text>
        </TouchableOpacity>
      </View>

      {isRecording && (
        <Text style={styles.recordingText}>Recording in progress...</Text>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: "#FCE4EC" },
  header: { flexDirection: "row", alignItems: "center", marginBottom: 20 },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#A6488E",
    marginLeft: 10,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 15,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#A6488E",
    marginBottom: 10,
  },
  question: {
    fontSize: 16,
    fontWeight: "600",
    color: "#A6488E",
    marginVertical: 5,
  },
  optionsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 10,
  },
  optionButton: {
    borderWidth: 1,
    borderColor: "#A6488E",
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 12,
    margin: 5,
  },
  optionButtonSelected: {
    backgroundColor: "#D32F2F",
  },
  optionText: { fontSize: 14, color: "#A6488E" },
  optionTextSelected: { color: "#fff", fontWeight: "bold" },
  sosButton: {
    backgroundColor: "#D32F2F",
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    marginBottom: 20,
  },
  sosButtonText: {
    color: "#fff",
    fontSize: 32,
    fontWeight: "bold",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#A6488E",
    marginBottom: 10,
  },
  contactCard: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  contactName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  contactActions: { flexDirection: "row", alignItems: "center" },
  iconButton: { marginHorizontal: 10 },
  rowButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  policeButton: {
    backgroundColor: "#D32F2F",
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
    alignItems: "center",
  },
  ambulanceButton: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
    alignItems: "center",
  },
  policeText: {
    color: "#fff",
    fontSize: 16,
    textAlign: "center",
  },
  ambulanceText: { color: "#fff", fontSize: 16 },
  recordingText: {
    fontSize: 16,
    color: "#D32F2F",
    textAlign: "center",
    marginTop: 10,
  },
});

export default SecureAssistScreen;
