import { useState } from "react";
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { NavigationProp } from '@react-navigation/native';

type RootStackParamList = {
  LoginScreen: undefined;
  RegisterScreen: undefined;
  PilotScreen: undefined;
};

type Props = NativeStackScreenProps<RootStackParamList, "LoginScreen">;

export default function LoginScreen({ navigation }: Props) {  
  const [passwordVisible, setPasswordVisible] = useState(false);

  return (
    <View style={styles.container}>
      {/* Title */}
      <View style={styles.titleContainer}>
        <Text style={styles.title}>NAMMA</Text>
        <Text style={styles.title1}>BUS</Text>
      </View>

      {/* Greeting */}
      <Text style={styles.greeting}>
        Hi, <Text style={styles.yellowText}>Login</Text> Now
      </Text>

      {/* Input Fields */}
      <View style={styles.inputContainer}>
        {/* Email */}
        <TextInput style={styles.input} placeholder="Enter Email" placeholderTextColor="black" />

        {/* Password */}
        <View style={styles.passwordContainer}>
          <TextInput
            style={styles.passwordInput}
            placeholder="Enter Password"
            placeholderTextColor="black"
            secureTextEntry={!passwordVisible}
          />
          <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)}>
            <Ionicons name={passwordVisible ? "eye-off" : "eye"} size={24} color="black" />
          </TouchableOpacity>
        </View>

        {/* Forgot Password */}
        <TouchableOpacity>
          <Text style={styles.forgotPassword}>Forgot Password?</Text>
        </TouchableOpacity>
      </View>

      {/*  Button */}
      <TouchableOpacity style={[styles.button, styles.yellowButton]}>
        <Text style={styles.buttonText}  onPress={() => navigation.navigate("PilotScreen")}>Login</Text>
      </TouchableOpacity>
      {/* Sign-up Text */}
<TouchableOpacity>
  <Text style={styles.signupText}
  onPress={() => navigation.navigate("RegisterScreen")}
  >
    Don't have an account? <Text style={styles.signupLink}>Sign Up</Text>
  </Text>
</TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#2E3A47",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingTop: 0,
    width: "100%",
  },

  titleContainer: {
    alignItems: "center",
    marginTop: 20,
  },

  title: {
    color: "white",
    fontSize: 48,
  },

  title1: {
    color: "#DCD243",
    fontSize: 48,
  },

  greeting: {
    fontSize: 39,
    color: "white",
    marginTop: 65,
    paddingRight: 40,
  },

  yellowText: {
    color: "#DCD243",
  },

  inputContainer: {
    marginTop: 50,
    width: "90%",
  },

  input: {
    width: "100%",
    backgroundColor: "#FDFBA1",
    paddingVertical: 15,
    paddingHorizontal: 15,
    borderRadius: 10,
    fontSize: 16,
    marginTop: 35,
  },

  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FDFBA1",
    borderRadius: 10,
    marginTop: 15,
    paddingHorizontal: 15,
  },

  passwordInput: {
    flex: 1, 
    fontSize: 16,
    paddingVertical: 15, 
  },

  forgotPassword: {
    color: "#CAC6C6",
    fontSize: 14,
    paddingTop: 9,
    alignSelf: "flex-end",
    marginRight: 10,
  },

  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    width: "30%",
    marginTop: 70,
  },

  yellowButton: {
    backgroundColor: "#F0E65D",
    marginTop:70,
  },

  buttonText: {
    color: "black",
    fontSize: 18,
  },

  signupText: {
    color: "#CAC6C6",
    fontSize: 16,
    marginTop: 15,
  },
  
  signupLink: {
    color: "#F0E65D",
    //fontWeight: "bold",
  },
  
});
